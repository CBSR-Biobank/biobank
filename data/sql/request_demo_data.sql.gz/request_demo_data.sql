-- MySQL dump 10.13  Distrib 5.1.41, for Win32 (ia32)
--
-- Host: localhost    Database: biobank2
-- ------------------------------------------------------
-- Server version	5.1.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


--
-- Dumping data for table `request`
--
LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
delete from request;
INSERT INTO `request` (id, submitted, accepted, shipped, waybill, state, address_id, site_id, study_id) VALUES (29,'2010-12-09 12:10:53',NULL,NULL,'testwaybill',2,1,1,2);
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `request_aliquot`
--
LOCK TABLES `request_aliquot` WRITE;
/*!40000 ALTER TABLE `request_aliquot` DISABLE KEYS */;
delete from request_aliquot;
INSERT INTO `request_aliquot` (id, state, claimed_by, aliquot_id, request_id) VALUES (500,0,NULL,1,29),(501,0,'me',2,29),(502,0,NULL,3,29),(503,0,'me',4,29),(504,0,NULL,5,29),(505,0,'me',6,29),(506,0,NULL,7,29),(507,0,'me',8,29),(508,0,NULL,9,29),(509,0,'me',10,29),(510,0,NULL,11,29),(511,0,'me',12,29),(512,0,NULL,13,29),(513,0,'me',14,29),(514,0,NULL,15,29),(515,0,'me',16,29),(516,0,NULL,17,29),(517,0,'me',18,29),(518,0,NULL,19,29),(519,0,'me',20,29),(520,0,NULL,21,29),(521,0,'me',22,29),(522,0,NULL,23,29),(523,0,'me',24,29),(524,0,NULL,25,29),(525,0,'me',26,29),(526,0,NULL,27,29),(527,0,'me',28,29),(528,0,NULL,29,29),(529,0,'me',30,29),(530,0,NULL,31,29),(531,0,'me',32,29),(532,0,NULL,33,29),(533,0,'me',34,29),(534,0,NULL,35,29),(535,0,'me',36,29),(536,0,NULL,37,29),(537,0,'me',38,29),(538,0,NULL,39,29),(539,0,'me',40,29),(540,0,NULL,41,29),(541,0,'me',42,29),(542,0,NULL,43,29),(543,0,'me',44,29),(544,0,NULL,45,29),(545,0,'me',46,29),(546,0,NULL,47,29),(547,0,'me',48,29),(548,0,NULL,49,29),(549,0,'me',50,29),(550,0,NULL,51,29),(551,0,'me',52,29),(552,0,NULL,53,29),(553,0,'me',54,29),(554,0,NULL,55,29),(555,0,'me',56,29),(556,0,NULL,57,29),(557,0,'me',58,29),(558,0,NULL,59,29),(559,0,'me',60,29),(560,0,NULL,61,29),(561,0,'me',62,29),(562,0,NULL,63,29),(563,0,'me',64,29),(564,0,NULL,65,29),(565,0,'me',66,29),(566,0,NULL,67,29),(567,0,'me',68,29),(568,0,NULL,69,29),(569,0,'me',70,29),(570,0,NULL,71,29),(571,0,'me',72,29),(572,0,NULL,73,29),(573,0,'me',74,29),(574,0,NULL,75,29),(575,0,'me',76,29),(576,0,NULL,77,29),(577,0,'me',78,29),(578,0,NULL,79,29),(579,0,'me',80,29),(580,0,NULL,81,29),(581,0,'me',82,29),(582,0,NULL,83,29),(583,0,'me',84,29),(584,0,NULL,85,29),(585,0,'me',86,29),(586,0,NULL,87,29),(587,0,'me',88,29),(588,0,NULL,89,29),(589,0,'me',90,29),(590,0,NULL,91,29),(591,0,'me',92,29),(592,0,NULL,93,29),(593,0,'me',94,29),(594,0,NULL,95,29),(595,0,'me',96,29),(596,0,NULL,97,29),(597,0,'me',98,29),(598,0,NULL,99,29),(599,0,'me',100,29),(600,0,NULL,101,29);
/*!40000 ALTER TABLE `request_aliquot` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `researcher`
--

LOCK TABLES `researcher` WRITE;
/*!40000 ALTER TABLE `researcher` DISABLE KEYS */;
delete from researcher;
/*!40000 ALTER TABLE `researcher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `research_group`
--
LOCK TABLES `research_group` WRITE;
/*!40000 ALTER TABLE `research_group` DISABLE KEYS */;
delete from research_group;
INSERT INTO `research_group` (id, name, name_short, study_id, address_id) VALUES (10,'testRG','testRG',2,1);
/*!40000 ALTER TABLE `research_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-18 13:49:30
